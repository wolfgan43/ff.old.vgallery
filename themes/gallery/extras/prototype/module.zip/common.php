<?php
cm::getInstance()->addEvent("on_before_page_process", "mod_[mod_prototype]_on_before_page_process", ffEvent::PRIORITY_NORMAL);
cm::getInstance()->addEvent("on_before_routing", "mod_[mod_prototype]_on_before_rounting", ffEvent::PRIORITY_NORMAL);
//cm::getInstance()->addEvent("mod_security_on_created_session", "mod_[mod_prototype]_mod_security_on_created_session", ffEvent::PRIORITY_NORMAL);

define("MOD_[MOD_PTOTOTYPE]_PATH", $cm->router->named_rules["[mod_prototype]"]->reverse); 
define("MOD_[MOD_PTOTOTYPE]_SERVICES_PATH", $cm->router->named_rules["[mod_prototype]_services"]->reverse);


if(!function_exists("check_function")) {
    function check_function($name, $module = null) {
        if(function_exists($name)) {
            return true;
        } else {
            if(strpos($name, "process_addon_") === 0) { 
                if(strlen($module) && file_exists(FF_DISK_PATH . "/modules/" . $module . "/library/process/addon/" . substr($name, strlen("process_addon_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . $module . "/library/process/addon/" . substr($name, strlen("process_addon_")) . "." . FF_PHP_EXT);
                } elseif(file_exists(FF_DISK_PATH . "/library/gallery/process/addon/" . substr($name, strlen("process_addon_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/gallery/process/addon/" . substr($name, strlen("process_addon_")) . "." . FF_PHP_EXT);
                }
                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "process_") === 0) {
                if(strlen($module) && file_exists(FF_DISK_PATH . "/modules/" . $module . "/library/process/" . substr($name, strlen("process_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . $module . "/library/process/" . substr($name, strlen("process_")) . "." . FF_PHP_EXT);
                } elseif(file_exists(FF_DISK_PATH . "/library/gallery/process/" . substr($name, strlen("process_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/gallery/process/" . substr($name, strlen("process_")) . "." . FF_PHP_EXT);
                }

                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "MD_general_") === 0) {
                require_once(FF_DISK_PATH . "/conf/gallery/modules/common" . "." . FF_PHP_EXT);
                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "MD_") === 0) {
                require_once(FF_DISK_PATH . "/conf/gallery/modules/" . substr($name, 3, strpos($name, "_", 4) - 3) . "/common" . "." . FF_PHP_EXT);
                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "ecommerce_cart_") === 0) {
                if(strlen($module) && file_exists(FF_DISK_PATH . "/modules/" . $module . "/library/ecommerce/cart/" . substr($name, strlen("ecommerce_cart_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . $module . "/library/ecommerce/cart/" . substr($name, strlen("ecommerce_cart_")) . "." . FF_PHP_EXT);
                } elseif(file_exists(FF_DISK_PATH . "/library/gallery/ecommerce/cart/" . substr($name, strlen("ecommerce_cart_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/gallery/ecommerce/cart/" . substr($name, strlen("ecommerce_cart_")) . "." . FF_PHP_EXT);
                }
                
                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
                
            } elseif(strpos($name, "ecommerce_") === 0) {
                if(strlen($module) && file_exists(FF_DISK_PATH . "/modules/" . $module . "/library/ecommerce/" . substr($name, strlen("ecommerce_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . $module . "/library/ecommerce/" . substr($name, strlen("ecommerce_")) . "." . FF_PHP_EXT);
                } elseif(file_exists(FF_DISK_PATH . "/library/gallery/ecommerce/" . substr($name, strlen("ecommerce_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/gallery/ecommerce/" . substr($name, strlen("ecommerce_")) . "." . FF_PHP_EXT);
                }
                
                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "class.") === 0) {
                if(strlen($module) && file_exists(FF_DISK_PATH . "/modules/" . $module . "/library/" . substr($name, strlen("class.")) . "/" . $name . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . $module . "/library/" . substr($name, strlen("class.")) . "/" . $name . "." . FF_PHP_EXT);
                } elseif(file_exists(FF_DISK_PATH . "/library/" . substr($name, strlen("class.")) . "/" . $name . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/" . substr($name, strlen("class.")) . "/" . $name . "." . FF_PHP_EXT);
                }
                
                if(class_exists(substr($name, strlen("class.")))) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "service_") === 0) {
                if(strlen($module) && file_exists(FF_DISK_PATH . "/modules/" . $module . "/library/service/" . substr($name, strlen("service_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . $module . "/library/service/" . substr($name, strlen("service_")) . "." . FF_PHP_EXT);
                } elseif(file_exists(FF_DISK_PATH . "/library/gallery/service/" . substr($name, strlen("service_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/gallery/service/" . substr($name, strlen("service_")) . "." . FF_PHP_EXT);
                }
                
                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "mod_") === 0) {
                if(file_exists(FF_DISK_PATH . "/modules/" . substr($name, 4, strpos($name, "_", 4) - 4) . "/events." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . substr($name, 4, strpos($name, "_", 4) - 4) . "/events." . FF_PHP_EXT);
                }
                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "job_") === 0) {
                if(strlen($module) && file_exists(FF_DISK_PATH . "/modules/" . $module . "/library/job/" . substr($name, strlen("job_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . $module . "/library/job/" . substr($name, strlen("job_")) . "." . FF_PHP_EXT);
                } elseif(file_exists(FF_DISK_PATH . "/library/gallery/job/" . substr($name, strlen("job_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/gallery/job/" . substr($name, strlen("job_")) . "." . FF_PHP_EXT);
                }

                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } elseif(strpos($name, "system_") === 0) {
                if(strlen($module) && file_exists(FF_DISK_PATH . "/modules/" . $module . "/library/system/" . substr($name, strlen("system_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/modules/" . $module . "/library/system/" . substr($name, strlen("system_")) . "." . FF_PHP_EXT);
                } elseif(file_exists(FF_DISK_PATH . "/library/gallery/system/" . substr($name, strlen("system_")) . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/gallery/system/" . substr($name, strlen("system_")) . "." . FF_PHP_EXT);
                }

                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                if(strlen($name) && file_exists(FF_DISK_PATH . "/library/gallery/common/" . $name . "." . FF_PHP_EXT)) {
                    require_once(FF_DISK_PATH . "/library/gallery/common/" . $name . "." . FF_PHP_EXT);
                }
                if(function_exists($name)) {
                    return true;
                } else {
                    return false;
                    /*ffErrorHandler::raise("Common Function Not Exist: " . $name, E_USER_ERROR, null, get_defined_vars());*/
                    die("Fatal Error: Common Function Not Exist");
                }
            }
        }    
    }
    
    
}


function mod_[mod_prototype]_on_before_page_process($cm) {
    $globals = ffGlobals::getInstance("gallery"); 
    
    
    if(strpos($cm->path_info, MOD_[MOD_PTOTOTYPE]_PATH) !== false) {
        if(is_dir(FF_DISK_PATH . FF_THEME_DIR . "/" . global_settings("MOD_[MOD_PTOTOTYPE]_THEME"))) {
            $cm->layout_vars["theme"] = global_settings("MOD_[MOD_PTOTOTYPE]_THEME");
        }
    }
}

function mod_[mod_prototype]_on_before_rounting($cm) {
     $permission = check_[mod_prototype]_permission(); 
    if($permission !== true
        && 
        (!(is_array($permission) && count($permission)
            && ($permission[global_settings("MOD_[MOD_PTOTOTYPE]_GROUP_ADMIN")]
            )
        ))
    ) {
        $cm->modules["restricted"]["menu"]["[mod_prototype]"]["hide"] = true;
        $cm->modules["restricted"]["menu"]["[mod_prototype]"]["elements"]["doctor"]["hide"] = true;
        $cm->modules["restricted"]["menu"]["[mod_prototype]"]["elements"]["expert"]["hide"] = true;
    } else {
        if(strpos($cm->path_info, MOD_[MOD_PTOTOTYPE]_PATH) !== false
        ) {
            if(is_dir(FF_DISK_PATH . FF_THEME_DIR . "library/jquery.ui/themes/" . global_settings("MOD_[MOD_PTOTOTYPE]_JQUERYUI_THEME"))) {
                $cm->oPage->jquery_ui_force_theme = global_settings("MOD_[MOD_PTOTOTYPE]_JQUERYUI_THEME");
            }

            if(!MOD_SEC_GROUPS || $permission["primary_group"] != global_settings("MOD_[MOD_PTOTOTYPE]_GROUP_ADMIN")) {
		        $cm->modules["restricted"]["menu"]["[mod_prototype]"]["hide"] = true;
		        $cm->modules["restricted"]["menu"]["[mod_prototype]"]["elements"]["doctor"]["hide"] = true;
		        $cm->modules["restricted"]["menu"]["[mod_prototype]"]["elements"]["expert"]["hide"] = true;
			}
            
            if(function_exists("check_function") && check_function("system_set_js")) {
                system_set_js($cm->oPage, $cm->path_info, false, "/modules/[mod_prototype]/themes/javascript", true);
            }
        }
    }
}

function check_[mod_prototype]_permission($check_group = null) {
    if(!MOD_SEC_GROUPS) 
        return true;

    $db = ffDB_Sql::factory();

    $user_permission = get_session("user_permission");
    $userID = get_session("UserID");

    if(is_array($user_permission) && count($user_permission) 
        && is_array($user_permission["groups"]) && count($user_permission["groups"])
        && $userID != MOD_SEC_GUEST_USER_NAME
    ) {
        if(!array_key_exists("permissions_custom", $user_permission))
            $user_permission["permissions_custom"] = array();

        if(!(array_key_exists("[mod_prototype]", $user_permission["permissions_custom"]) && count($user_permission["permissions_custom"]["[mod_prototype]"]))) {
            $user_permission["permissions_custom"]["[mod_prototype]"] = array();
            
            $strGroups = implode(",", $user_permission["groups"]);
            $strPermission = $db->toSql(global_settings("MOD_[MOD_PTOTOTYPE]_GROUP_ADMIN"), "Text");

            $user_permission["permissions_custom"]["[mod_prototype]"][global_settings("MOD_[MOD_PTOTOTYPE]_GROUP_ADMIN")] = false;
            $user_permission["permissions_custom"]["[mod_prototype]"]["primary_group"] = "";
            
            $sSQL = "SELECT DISTINCT " . CM_TABLE_PREFIX . "mod_security_groups.name
                        , (SELECT GROUP_CONCAT(anagraph.ID) FROM anagraph WHERE anagraph.uid = " . $db->toSql(get_session("UserNID"), "Number") . ") AS anagraph
                    FROM " . CM_TABLE_PREFIX . "mod_security_groups
                      INNER JOIN " . CM_TABLE_PREFIX . "mod_security_users_rel_groups ON " . CM_TABLE_PREFIX . "mod_security_users_rel_groups.gid = " . CM_TABLE_PREFIX . "mod_security_groups.gid
                    WHERE " . CM_TABLE_PREFIX . "mod_security_users_rel_groups.gid IN ( " . $db->toSql($strGroups, "Text", false) . " )
                      AND " . CM_TABLE_PREFIX . "mod_security_groups.name IN ( " . $strPermission . " )";
            $db->query($sSQL);
            if($db->nextRecord()) {
                do {
                    $user_permission["permissions_custom"]["[mod_prototype]"][$db->getField("name", "Text", true)] = true;
                    $user_permission["permissions_custom"]["[mod_prototype]"]["primary_group"] = $db->getField("name", "Text", true);
                } while($db->nextRecord());
            }
            
            set_session("user_permission", $user_permission);
        }
        if($check_group === null) { 
            return $user_permission["permissions_custom"]["[mod_prototype]"];
        } else {
            return $user_permission["permissions_custom"]["[mod_prototype]"]["primary_group"];
        }
    }    
    return null;
}

function mod_[mod_prototype]_mod_security_on_created_session($UserID, $UserNID, $Domain, $DomainID, $old_session_id) {
    $user_permission = get_session("user_permission");

    if($user_permission["primary_gid_name"] == global_settings("MOD_[MOD_PTOTOTYPE]_GROUP_ADMIN")) {
        if(strlen(MOD_[MOD_PTOTOTYPE]_PATH)) {
            if(strpos($_REQUEST["ret_url"], MOD_[MOD_PTOTOTYPE]_PATH) !== 0) {
                ffRedirect(FF_SITE_PATH . MOD_[MOD_PTOTOTYPE]_PATH);
            }
        }
    }

    if(strtolower($user_permission["primary_gid_name"]) == "[mod_prototype]"
    ) {
    }
}
?>