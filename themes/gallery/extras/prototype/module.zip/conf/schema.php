<?php
	$schema = array();
    $schema["db"]["table_prefix"] = "cm_mod_[mod_prototype]_";
    $schema["db"]["schema"]["data"]["cm_mod_security_groups"][] = array("ID" => null
     														, "name" => "[mod_prototype]-admin"
     														, "level" => 10
     													);
?>